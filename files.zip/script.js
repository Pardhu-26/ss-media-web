/* ============================================
   SSMEDIA – script.js
   ============================================ */

'use strict';

// =============================================
// 1. NAVBAR – sticky + mobile toggle
// =============================================
(function () {
  const navbar = document.getElementById('navbar');
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('nav-links');
  const allNavLinks = navLinks.querySelectorAll('a');

  // Scroll: add class
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 40);
  }, { passive: true });

  // Hamburger toggle
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    navLinks.classList.toggle('open');
  });

  // Close mobile menu on link click
  allNavLinks.forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('open');
      navLinks.classList.remove('open');
    });
  });

  // Active link on scroll
  const sections = document.querySelectorAll('section[id]');
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY + 100;
    sections.forEach(sec => {
      const top = sec.offsetTop;
      const height = sec.offsetHeight;
      const id = sec.getAttribute('id');
      const link = navLinks.querySelector(`a[href="#${id}"]`);
      if (link) {
        link.style.color = (scrollY >= top && scrollY < top + height)
          ? 'var(--gold)' : '';
      }
    });
  }, { passive: true });
})();

// =============================================
// 2. SCROLL REVEAL
// =============================================
(function () {
  const revealEls = document.querySelectorAll('.reveal, .reveal-right');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const delay = el.dataset.delay ? parseInt(el.dataset.delay) : 0;
        setTimeout(() => el.classList.add('visible'), delay);
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.12 });

  revealEls.forEach(el => observer.observe(el));
})();

// =============================================
// 3. SKILL BAR ANIMATION
// =============================================
(function () {
  const bars = document.querySelectorAll('.bar-fill');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bar = entry.target;
        bar.style.width = bar.dataset.width;
        observer.unobserve(bar);
      }
    });
  }, { threshold: 0.4 });
  bars.forEach(b => observer.observe(b));
})();

// =============================================
// 4. PORTFOLIO FILTER
// =============================================
(function () {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const items = document.querySelectorAll('.portfolio-item');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;

      items.forEach(item => {
        const cat = item.dataset.cat;
        if (filter === 'all' || cat === filter) {
          item.classList.remove('hidden');
          item.style.animation = 'none';
          requestAnimationFrame(() => {
            item.style.animation = 'fadeIn 0.4s ease both';
          });
        } else {
          item.classList.add('hidden');
        }
      });
    });
  });
})();

// =============================================
// 5. GALLERY LIGHTBOX
// =============================================
(function () {
  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const closeBtn = document.getElementById('lightboxClose');
  const prevBtn = document.getElementById('lightboxPrev');
  const nextBtn = document.getElementById('lightboxNext');

  let currentIndex = 0;
  const srcs = Array.from(galleryItems).map(item => item.dataset.src);

  function openLightbox(index) {
    currentIndex = index;
    lightboxImg.src = srcs[index];
    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    lightbox.classList.remove('active');
    lightboxImg.src = '';
    document.body.style.overflow = '';
  }

  galleryItems.forEach((item, i) => {
    item.addEventListener('click', () => openLightbox(i));
  });

  closeBtn.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });

  prevBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    currentIndex = (currentIndex - 1 + srcs.length) % srcs.length;
    lightboxImg.style.opacity = 0;
    setTimeout(() => {
      lightboxImg.src = srcs[currentIndex];
      lightboxImg.style.opacity = 1;
    }, 150);
  });

  nextBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    currentIndex = (currentIndex + 1) % srcs.length;
    lightboxImg.style.opacity = 0;
    setTimeout(() => {
      lightboxImg.src = srcs[currentIndex];
      lightboxImg.style.opacity = 1;
    }, 150);
  });

  // Keyboard navigation
  document.addEventListener('keydown', e => {
    if (!lightbox.classList.contains('active')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') prevBtn.click();
    if (e.key === 'ArrowRight') nextBtn.click();
  });

  // Transition for image
  lightboxImg.style.transition = 'opacity 0.15s ease';
})();

// =============================================
// 6. BACK TO TOP BUTTON
// =============================================
(function () {
  const btn = document.getElementById('backToTop');
  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });
  btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
})();

// =============================================
// 7. HERO PARTICLE CANVAS
// =============================================
(function () {
  const container = document.getElementById('particles');
  const canvas = document.createElement('canvas');
  container.appendChild(canvas);
  const ctx = canvas.getContext('2d');

  let W, H, particles = [];

  function resize() {
    W = canvas.width = container.offsetWidth;
    H = canvas.height = container.offsetHeight;
  }

  function rand(min, max) { return Math.random() * (max - min) + min; }

  function createParticle() {
    return {
      x: rand(0, W),
      y: rand(0, H),
      r: rand(0.5, 2.2),
      vx: rand(-0.3, 0.3),
      vy: rand(-0.6, -0.15),
      alpha: rand(0.2, 0.7),
      color: Math.random() > 0.6 ? '#F5B301' : '#E8001D',
    };
  }

  function init() {
    particles = [];
    for (let i = 0; i < 80; i++) particles.push(createParticle());
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.alpha;
      ctx.fill();

      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= 0.0008;

      if (p.y < -5 || p.alpha <= 0) {
        Object.assign(p, createParticle());
        p.y = H + 5;
        p.alpha = rand(0.2, 0.7);
      }
    });
    ctx.globalAlpha = 1;
    requestAnimationFrame(draw);
  }

  resize();
  init();
  draw();
  window.addEventListener('resize', () => { resize(); init(); }, { passive: true });
})();

// =============================================
// 8. SMOOTH SCROLL for anchor links
// =============================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const offset = 70;
    const top = target.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

// =============================================
// 9. COUNTER ANIMATION (Stats)
// =============================================
(function () {
  const stats = document.querySelectorAll('.stat-num');
  const targets = [500, 8, 300];
  let animated = false;

  const observer = new IntersectionObserver((entries) => {
    if (!animated && entries.some(e => e.isIntersecting)) {
      animated = true;
      stats.forEach((el, i) => {
        const target = targets[i];
        const suffix = el.textContent.replace(/[0-9]/g, '');
        let count = 0;
        const step = Math.ceil(target / 60);
        const timer = setInterval(() => {
          count = Math.min(count + step, target);
          el.textContent = count + suffix;
          if (count >= target) clearInterval(timer);
        }, 30);
      });
    }
  }, { threshold: 0.5 });

  if (stats.length > 0) observer.observe(stats[0]);
})();

// =============================================
// 10. CSS Keyframe injection for filterIn
// =============================================
(function () {
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(16px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(style);
})();
